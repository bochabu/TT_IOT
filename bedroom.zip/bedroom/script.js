// sensor 1
var temperature = 45; 

document.querySelector('.temperature-display').innerText = temperature + '°C';
document.querySelector('.temperature-bar').style.height = ((temperature + 25) * 1.23) + '%';

//máy lạnh
let acOn = false;

function toggleAC() {
    acOn = !acOn;
    document.getElementById('ac-status').classList.toggle('hidden', !acOn);
    document.getElementById('ac-status').classList.toggle('shown', acOn);
    document.getElementById('ac-status-off').classList.toggle('hidden', acOn);
    document.getElementById('ac-status-off').classList.toggle('shown', !acOn);
    document.getElementById('temp-display').classList.toggle('hidden', !acOn);
    document.getElementById('timer-display').classList.toggle('hidden', !acOn);
}

function startTimer() {
    const timerInput = document.getElementById('timer').value;
    const [hours, minutes, seconds] = timerInput.split(':').map(Number);
    const totalSeconds = hours * 3600 + minutes * 60 + seconds;
    let remainingSeconds = totalSeconds;
    const timerInterval = setInterval(() => {
        remainingSeconds--;
        const hrs = Math.floor(remainingSeconds / 3600);
        const mins = Math.floor((remainingSeconds % 3600) / 60);
        const secs = remainingSeconds % 60;
        document.getElementById('timer').value = `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        if (remainingSeconds <= 0) {
            clearInterval(timerInterval);
            toggleAC();
        }
    }, 1000);
}

// sensor 2
const lightImage = document.getElementById('lightImage');
const lightStatus = document.getElementById('lightStatus');
const lightValue = document.getElementById('lightValue');

function updateLightStatus(lux) {
    lightValue.textContent = lux;
    if (lux >= 1 && lux <= 10) {
        lightStatus.textContent = 'Status: Low night light';
        lightImage.src = 'lightsensor.png';
    } else if (lux > 10 && lux <= 20) {
        lightStatus.textContent = 'Status: Medium night light';
        lightImage.src = 'lightsensor.png';
    } else if (lux > 20 && lux <= 40) {
        lightStatus.textContent = 'Status: High night light';
        lightImage.src = 'lightsensor.png';
    } else if (lux > 40 && lux <= 150) {
        lightStatus.textContent = 'Status: Suitable for watching TV or resting';
        lightImage.src = 'lightsensor.png';
    } else if (lux > 150 && lux <= 300) {
        lightStatus.textContent = 'Status: Suitable for reading and writing';
        lightImage.src = 'lightsensor.png';
    } else if (lux > 300 && lux <= 1000) {
        lightStatus.textContent = 'Status: Suitable for working';
        lightImage.src = 'lightsensor.png';
    } else {
        lightStatus.textContent = 'Status: Unknown';
        lightImage.src = 'lightsensor.png';
    }
}

// light
const ledImage = document.getElementById('light-Image');
const sliderContainerOn = document.getElementById('slider-container-on');
const sliderContainerNight = document.getElementById('slider-container-night');
const brightnessRangeOn = document.getElementById('brightnessRangeOn');
const brightnessRangeNight = document.getElementById('brightnessRangeNight');
const ledValue = document.getElementById('light-value');
const ledStatus = document.getElementById('light-status');
const lightInfo = document.getElementById("light-info");
const butledon = document.getElementById("butledon");
const butlednl = document.getElementById("butlednl");
const butledoff = document.getElementById("butledoff");

function controlLight(mode) {
    if (mode === 'off') {
        ledImage.src = 'off.png';
        sliderContainerOn.style.display = 'none';
        sliderContainerNight.style.display = 'none';
        brightnessRangeOn.value = 0;
        brightnessRangeNight.value = 0;
    } else if (mode === 'on') {
        sliderContainerOn.style.display = 'block';
        sliderContainerNight.style.display = 'none';
    } else if (mode === 'night-light') {
        sliderContainerOn.style.display = 'none';
        sliderContainerNight.style.display = 'block';
    }
}

brightnessRangeOn.addEventListener('input', function () {
    const brightnessValue = this.value;
    if (brightnessValue == 0) {
        ledImage.src = 'off.png';
    } else if (brightnessValue < 33){
        ledImage.src = 'normal2.png';
    } else if (brightnessValue < 66){
        ledImage.src = 'normal3.png';
    } else {
        ledImage.src = 'normal4.png';
    }
});

brightnessRangeNight.addEventListener('input', function () {
    const brightnessValue = this.value;
    if (brightnessValue == 0) {
        ledImage.src = 'off.png';
    } else if (brightnessValue < 33){
        ledImage.src = 'nl2.png';
    } else if (brightnessValue < 66){
        ledImage.src = 'nl3.png';
    } else {
        ledImage.src = 'nl4.png';
    }
});

function updateLedStatus1(lux) {
    ledValue.textContent = lux;
    if (lux >= 1 && lux <= 10) {
        ledStatus.textContent = 'Status: Low night light';
    } else if (lux > 10 && lux <= 20) {
        ledStatus.textContent = 'Status: Medium night light';
    } else if (lux > 20 && lux <= 40) {
        ledStatus.textContent = 'Status: High night light';
    } else if (lux > 40 && lux <= 150) {
        ledStatus.textContent = 'Status: Suitable for watching TV or resting';
    } else if (lux > 150 && lux <= 300) {
        ledStatus.textContent = 'Status: Suitable for reading and writing';
    } else if (lux > 300 && lux <= 1000) {
        ledStatus.textContent = 'Status: Suitable for working';
    } else {
        ledStatus.textContent = 'Status: Unknown';
    }
}

let LightValue = 30;
updateLightStatus(LightValue); 
updateLedStatus1(LightValue);

// sensor 3
const dustValue = document.getElementById("dust-value");
const statusText = document.getElementById("status");
const airstatusText = document.getElementById("air-status");
const statusImage = document.getElementById("status-image");

function updateDustStatus(value) {
    dustValue.textContent = value;
    if (value <= 12) {
        statusText.textContent = "Good";
        statusImage.src = "good.png";
    } else if (value <= 35) {
        statusText.textContent = "Moderate";
        statusImage.src = "moderate.png";
    } else {
        statusText.textContent = "Poor";
        statusImage.src = "poor.png";
    }
    if (value > 12) {
        turnOnAirPurifier();
    }
}

//Air Purifier
const powerButton = document.getElementById("power-button");
const purifierImage = document.getElementById("purifier-image");
const dustInfo = document.getElementById("dust-info");
const airValue = document.getElementById("air-value");
const airStatus = document.getElementById("air-status");

function updateDustStatus1(value) {
    airValue.textContent = value;
    if (value <= 12) {
        airStatus.textContent = "Good";
    } else if (value <= 35) {
        airStatus.textContent = "Moderate";
    } else {
        airStatus.textContent = "Poor";
    }
}

function turnOnAirPurifier() {
    powerButton.textContent = "Off";
    purifierImage.src = "buimo.png";
    dustInfo.style.display = "table"; 
}

function turnOffAirPurifier() {
    powerButton.textContent = "On";
    purifierImage.src = "buitat.png";
    dustInfo.style.display = "none"; 
}

powerButton.addEventListener("click", function () {
    if (powerButton.textContent === "On") {
        turnOnAirPurifier();
    } else {
        turnOffAirPurifier();
    }
});

let DustValue = 12;
updateDustStatus(DustValue);
updateDustStatus1(DustValue);




